# Aluno: Otávio Ramos Teixeira 20421244 (4030)
# Prova: Prova 3 - Quinta 15 (2669)
# Questao: 3, 1a tentativa, nota: 10
# Problema: Soma de números (0001)
# Turma(s): FP1 3A, semestre: 2026/1, e-mail: otavio.teixeira@estudante.ufla.br
# Justificativa da nota: Questão resolvida corretamente.

# Programa para somar dois números

numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

soma = numero1 + numero2

print("Resultado:", soma)
