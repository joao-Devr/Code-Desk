# Aluno: João Pedro Nascimento 20421240 (4026)
# Prova: Prova 3 - Quinta 15 (2669)
# Questao: 1, 1a tentativa, nota: 10
# Problema: Leitura e impressão de dados (0000)
# Turma(s): FP1 3A, semestre: 2026/1, e-mail: joao.nascimento@estudante.ufla.br
# Justificativa da nota: Questão resolvida corretamente.

# Programa para ler o nome e a idade e exibir uma mensagem

nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))

print(f"Olá, {nome}! Você tem {idade} anos.")
